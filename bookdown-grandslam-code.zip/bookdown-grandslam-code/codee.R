getwd()
setwd("C:/PROJECT/personal/UNCC/Visual_Analytic/book/bookdown-demo-master")



install.packages('bookdown')


bookdown::publish_book(render = 'local')
y
y